<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
      <div class="flex items-center justify-between">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__($title)); ?>

        </h2>
        <?php if(Auth::check() && Auth::user()->is_admin): ?>
          <a href="<?php echo e(route('books.create', ['categories' => $categories])); ?>">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>+ New Book <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
          </a>
        <?php endif; ?>
      </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <div class="flex justify-center">
                    <div class="w-1/3 py-2">
                      <form action="<?php echo e(route('books.search')); ?>" method="get">
                        <?php echo csrf_field(); ?>
                        <div class="xl:w-96">
                          <div class="input-group relative flex flex-wrap items-stretch w-full mb-4">
                            <input type="search" name="q" id="q" class="form-control relative flex-auto min-w-0 block w-full px-3 py-1.5 text-base font-normal text-gray-700 bg-white bg-clip-padding border border-solid border-gray-300 rounded transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none" placeholder="Search Books" <?php if($title != "Books"): ?> value="<?php echo e($title); ?>" <?php endif; ?> aria-label="Search Book">
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['class' => 'btn px-6 py-2.5 text-white font-medium text-xs leading-tight uppercase rounded shadow-md hover:bg-blue-700 hover:shadow-lg focus:bg-blue-700  focus:shadow-lg focus:outline-none focus:ring-0 active:bg-blue-800 active:shadow-lg transition duration-150 ease-in-out flex items-center','type' => 'submit']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'btn px-6 py-2.5 text-white font-medium text-xs leading-tight uppercase rounded shadow-md hover:bg-blue-700 hover:shadow-lg focus:bg-blue-700  focus:shadow-lg focus:outline-none focus:ring-0 active:bg-blue-800 active:shadow-lg transition duration-150 ease-in-out flex items-center','type' => 'submit']); ?>
                              <svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="search" class="w-4" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                <path fill="currentColor" d="M505 442.7L405.3 343c-4.5-4.5-10.6-7-17-7H372c27.6-35.3 44-79.7 44-128C416 93.1 322.9 0 208 0S0 93.1 0 208s93.1 208 208 208c48.3 0 92.7-16.4 128-44v16.3c0 6.4 2.5 12.5 7 17l99.7 99.7c9.4 9.4 24.6 9.4 33.9 0l28.3-28.3c9.4-9.4 9.4-24.6.1-34zM208 336c-70.7 0-128-57.2-128-128 0-70.7 57.2-128 128-128 70.7 0 128 57.2 128 128 0 70.7-57.2 128-128 128z"></path>
                              </svg>
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                          </div>
                        </div>
                      </form>
                      </div>
                    </div>

                    <div class="flex justify-center mb-4 py-2">
                      <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['onclick' => 'document.location=\'/books\'']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['onclick' => 'document.location=\'/books\'']); ?>All <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['onclick' => 'document.location=\'/books/cat/'.e($category->id).'\'']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['onclick' => 'document.location=\'/books/cat/'.e($category->id).'\'']); ?><?php echo e($category->name); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <?php if(Auth::check() && Auth::user()->is_admin): ?>

                      <div class="flex justify-center">
                        <div class="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
                            <div class="py-2 align-middle inline-block min-w-full sm:px-6 lg:px-8">
                                <?php if(count($books) == 0): ?>
                                  <div class="flex justify-center py-6">
                                    <span class="font-semibold text-xl text-gray-800">No books found.</span>
                                  </div>
                                <?php else: ?>
                                <div class="shadow overflow-hidden border-b border-gray-200 sm:rounded-lg">
                                    <table class="min-w-full divide-y divide-gray-200">
                                        <thead class="bg-gray-100">
                                        <tr class="border-b">
                                            <th scope="col" class="px-6 py-4 text-sm font-medium text-gray-900 uppercase">
                                              Cover
                                            </th>
                                            <th scope="col" class="px-6 py-4 text-sm font-medium text-gray-900 uppercase">
                                              Book
                                            </th>
                                            <th scope="col" class="px-6 py-4 text-sm font-medium text-gray-900 uppercase">
                                              Category
                                            </th>
                                            <th scope="col" class="px-6 py-4 text-sm font-medium text-gray-900 uppercase">
                                              Author
                                            </th>
                                            <th scope="col" class="relative px-6 py-4 text-sm font-medium text-gray-900 uppercase">
                                              Action
                                            </th>
                                        </tr>
                                        </thead>
                                        <tbody class="bg-white divide-y divide-gray-200">
                                        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="border-b">
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                <img src="<?php echo e(asset('/storage/' . $book->cover)); ?>" class="h-30 w-20 shadow-sm sm:rounded-lg">
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                <?php echo e($book->title); ?>

                                                <div class="flex items-center">
                                                  <?php if($book->reviews->count() != null): ?>
                                                    <a><?php echo e($book->reviews->avg('rating')); ?> ★・</a>
                                                  <?php else: ?>
                                                    <a>0 ★・</a>
                                                  <?php endif; ?>
                                                  <span ><?php echo e($book->reviews->count()); ?> review(s)</span>
                                                </div>
                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                <?php echo e($book->category->name); ?>

                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                <?php echo e($book->author); ?>

                                            </td>
                                            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                                <form action="/books/<?php echo e($book->id); ?>" method="post">
                                                  <?php echo method_field('DELETE'); ?>
                                                  <?php echo csrf_field(); ?>
                                                  <a href="<?php echo e(route('books.show', $book)); ?>" class="text-indigo-600 hover:text-indigo-900">View</a> ・ 
                                                  <a href="<?php echo e(route('books.edit', $book)); ?>" class="text-indigo-600 hover:text-indigo-900">Edit</a> ・ 
                                                  <a class="text-red-600"> 
                                                  <button type="submit">Delete</button>
                                                  </a>
                                                </form>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                      </div>
                    <?php else: ?>

                      <div class="flex max-w-6xl py-6 justify-center">
                      <?php if(count($books) == 0): ?>
                        <div class="flex justify-center py-6">
                          <span class="font-semibold text-xl text-gray-800">No books found.</span>
                        </div>
                      <?php else: ?>
                        <?php for($i = 0; $i < 4; $i++): ?>
                          <?php if($books[$i] != null): ?>
                            <div class="flex flex-col mx-1.5">
                              <a href="<?php echo e(route('books.show', $books[$i])); ?>">
                                <div class="flex-1 bg-gray-800 overflow-hidden shadow sm:rounded-lg w-60">
                                  <div class="flex justify-center">
                                    <img src="<?php echo e(asset('/storage/' . $books[$i]->cover)); ?>">
                                  </div>
                                  <div class="p-6">
                                    <p class="block font-semibold text-xl text-white mb-2"><?php echo e($books[$i]->title); ?></p>
                                    <p class="text-gray-300 text-base"><?php echo e($books[$i]->category->name); ?></p>
                                    <p class="text-gray-400 text-base"><?php echo e($books[$i]->author); ?></p>
                                    <div class="flex items-center">
                                      <?php if($books[$i]->reviews->count() != null): ?>
                                        <a class="text-gray-300 text-sm"><?php echo e($books[$i]->reviews->avg('rating')); ?> ★・</a>
                                      <?php else: ?>
                                        <a class="text-sm text-gray-300">0 ★・</a>
                                      <?php endif; ?>
                                      <span class="text-sm text-gray-300"><?php echo e($books[$i]->reviews->count()); ?> review(s)</span>
                                    </div>
                                  </div>
                                </div>
                              </a>
                            </div>
                          <?php endif; ?>
                        <?php endfor; ?>
                      </div>
                      <div class="flex max-w-6xl py-6 justify-center">
                        <?php for($i = 4; $i < 8; $i++): ?>
                          <?php if($books[$i] != null): ?>
                            <div class="flex flex-col mx-1.5">
                              <a href="<?php echo e(route('books.show', $books[$i])); ?>">
                                <div class="flex-1 bg-gray-800 overflow-hidden shadow sm:rounded-lg w-60">
                                  <div class="flex justify-center">
                                    <img src="<?php echo e(asset('/storage/' . $books[$i]->cover)); ?>">
                                  </div>
                                  <div class="p-6">
                                    <p class="block font-semibold text-xl text-white mb-2"><?php echo e($books[$i]->title); ?></p>
                                    <p class="text-gray-300 text-base"><?php echo e($books[$i]->category->name); ?></p>
                                    <p class="text-gray-400 text-base"><?php echo e($books[$i]->author); ?></p>
                                    <div class="flex items-center">
                                      <?php if($books[$i]->reviews->count() != null): ?>
                                        <a class="text-gray-300 text-sm"><?php echo e($books[$i]->reviews->avg('rating')); ?> ★・</a>
                                      <?php else: ?>
                                        <a class="text-sm text-gray-300">0 ★・</a>
                                      <?php endif; ?>
                                      <span class="text-sm text-gray-300"><?php echo e($books[$i]->reviews->count()); ?> review(s)</span>
                                    </div>
                                  </div>
                                </div>
                              </a>
                            </div>
                          <?php endif; ?>
                        <?php endfor; ?>
                      </div>
                      <?php endif; ?>

                      <?php endif; ?>
                      <?php echo e($books->links()); ?>

                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\lachisean-library\lachisean-library\resources\views/books/index.blade.php ENDPATH**/ ?>