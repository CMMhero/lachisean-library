<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Book Detail')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <div class="flex flex-wrap">
                        <div class="w-1/6 py-4 px-4">
                            <img src="<?php echo e(asset('/storage/' . $book->cover)); ?>" class="w-full shadow-sm sm:rounded-lg">
                            <div class="flex items-center justify-center mt-4">
                            <?php if($book->reviews->count() != null): ?>
                                <a class="text-gray-600"><?php echo e($book->reviews->avg('rating')); ?> ★</a>
                            <?php else: ?>
                                <a class="text-gray-600">0 ★</a>
                            <?php endif; ?>
                            </div>
                        </div>
                        <div class="w-5/6 py-4 px-4">
                            <h1 class="text-xl font-semibold"><?php echo e($book->title); ?></h1>
                            <p><?php echo e($book->author); ?></p>
                            <p><?php echo e($book->category->name); ?></p>
                            <p class="py-6 text-gray-600 text-sm"><?php echo e($book->description); ?></p>
                            <?php if(Auth::check() && Auth::user()->is_admin): ?>
                                <a href="/books/<?php echo e($book->id); ?>/edit">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Edit <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="p-6 bg-white border-b border-gray-200">
                    <p class="font-semibold text-xl">Recommended Books</p>
                    <?php if($recommendedBooks->count() == 0): ?>
                        <p class="text-gray-600">No recommended books yet</p>
                    <?php else: ?>
                        <div class="flex items-center py-2 mx-auto">
                        <?php $__currentLoopData = $recommendedBooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recommendedBook): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="/books/<?php echo e($recommendedBook->id); ?>">
                                    <div class="mr-4 mx-auto">
                                        <img src="<?php echo e(asset('/storage/' . $recommendedBook->cover)); ?>" class="w-20 shadow-sm sm:rounded-lg">
                                    </div>
                                    <div class="ml-4 mx-auto">
                                        <a href="/books/<?php echo e($recommendedBook->id); ?>" class="font-semibold"><?php echo e($recommendedBook->title); ?></a><br/>
                                        <a class="text-gray-600 text-sm"><?php echo e($recommendedBook->author); ?></a><br/>
                                        <a class="text-gray-600 text-sm"><?php echo e($recommendedBook->category->name); ?></a>
                                        <div class="flex items-center">
                                        <?php if($recommendedBook->reviews->count() != null): ?>
                                            <a class="text-gray-600 text-sm"><?php echo e($recommendedBook->reviews->avg('rating')); ?> ★・</a>
                                        <?php else: ?>
                                            <a class="text-sm text-gray-600">0 ★・</a>
                                        <?php endif; ?>
                                        <span class="text-sm text-gray-600"><?php echo e($recommendedBook->reviews->count()); ?> review(s)</span>
                                        </div>
                                    </div>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                </div>

                  <div class="p-6 bg-white border-b border-gray-200">
                      <p class="font-semibold text-xl">Reviews</p>
                        <?php if($book->reviews->count() == 0): ?>
                            <p class="text-gray-600">No reviews yet</p>
                        <?php else: ?>
                        <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="flex py-2">
                            <a href="<?php echo e(route('users.show', $review->user->id)); ?>">
                                <div class="mr-4">
                                    <img src="<?php echo e(asset('/storage/' . $review->user->photo)); ?>" class="h-20 w-20 shadow-sm circle fill">
                                </div>
                                <div class="ml-4 w-5/6">
                                    <strong><?php echo e($review->user->name); ?></strong></a>・<a class="text-gray-600 text-sm"><?php echo e($review->created_at->diffForHumans()); ?></a>
                                        <?php if($review->updated_at != $review->created_at): ?>
                                            <a class="text-gray-600 text-sm">(edited)</a>
                                        <?php endif; ?>
                                    <br/>
                                    <?php for($i = 0; $i < $review->rating; $i++): ?>
                                        <a class="text-gray-600 text-sm">★</a>
                                    <?php endfor; ?>
                                    <p><?php echo e($review->content); ?></p>
                                    <?php if(Auth::check() && $review->user->id == Auth::user()->id && $book->reviews->where('user_id', Auth::user()->id)->count() > 0): ?>
                                        <div class="flex items-center">
                                            <div>
                                                <form action="<?php echo e(route('reviews.destroy', $book->reviews->where('user_id', Auth::user()->id)->first()->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <a class="text-indigo-600 text-sm" href="<?php echo e(route('reviews.edit', $book->reviews->where('user_id', Auth::user()->id)->first()->id)); ?>">Edit My Review</a> ・ 
                                                    <a class="text-red-600 text-sm">
                                                    <button type="submit">Delete My Review</button>
                                                    </a>
                                                </form>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    <?php if(Auth::check() && Auth::user()->is_admin && $review->user->id != Auth::user()->id): ?>
                                        <form action="<?php echo e(route('reviews.destroy', $review->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="text-red-600 text-sm">Delete this review</button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                    <?php if(Auth::check()): ?>
                        <?php if($book->reviews->where('user_id', Auth::user()->id)->count() == 0): ?>
                        <div class="py-4">
                            <form action="/reviews" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="book_id" value="<?php echo e($book->id); ?>">
                            <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                            <div>
                                <textarea class="block mt-1 w-full sm:rounded-lg shadow-sm border-gray-300" name="content" rows="5" cols="50" required></textarea><br/>
                                <div>
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.label','data' => ['for' => 'rating','value' => __('Rating')]] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'rating','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Rating'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                    <div class="mt-1 w-20">
                                        <select name="rating" id="rating" required class="block mt-1 w-full sm:rounded-lg shadow-sm border-gray-300">
                                            <option value="1">1</option>
                                            <option value="2">2</option>
                                            <option value="3">3</option>
                                            <option value="4">4</option>
                                            <option value="5">5</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['class' => 'mt-4','type' => 'submit']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mt-4','type' => 'submit']); ?>Add Review <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            </form>
                        </div>
                        <?php endif; ?>
                    <?php echo e($reviews->links()); ?>

                    <?php else: ?>
                    <div class="py-4 flex justify-center">
                      <p>You must <a class="text-indigo-600" href="<?php echo e(route('login')); ?>">log in</a> to add a review.</p>
                    </div>
                    <?php endif; ?>
                  </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\uas-kelompok-lachisean\uas-kelompok-lachisean\resources\views/books/show.blade.php ENDPATH**/ ?>