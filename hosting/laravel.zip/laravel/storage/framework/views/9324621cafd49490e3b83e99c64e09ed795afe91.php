<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
      <div class="flex items-center justify-between">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__($user->name . "'s Profile")); ?>

        </h2>
      </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <div class="flex items-center">
                    <div class="mr-4">
                        <img src="<?php echo e(asset('/storage/' . $user->photo)); ?>" class="h-20 w-20 shadow-sm circle fill">
                    </div>
                    <div class="ml-4">
                        <a class="font-semibold text-xl"><?php echo e($user->name); ?></a><br/>
                        <?php echo e($user->email); ?><br/>
                        Joined at <?php echo e(date('d F Y', strtotime($user->created_at))); ?><br/>
                        <?php if(Auth::check() && Auth::user()->id == $user->id): ?>
                            <a href="/users/<?php echo e($user->id); ?>/edit">
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Edit <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
                </div>
                <div class="p-6 bg-white border-b border-gray-200">
                        <p class="font-semibold text-xl">Reviews</p>
                        <?php if($user->reviews->count() == 0): ?>
                            <p class="text-gray-600">No reviews yet</p>
                        <?php else: ?>
                            <?php $__currentLoopData = $user->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="/books/<?php echo e($review->book->id); ?>">
                                <div class="flex py-2">
                                    <div class="mr-4">
                                        <img src="<?php echo e(asset('/storage/' . $review->book->cover)); ?>" class="w-20 shadow-sm sm:rounded-lg">
                                    </div>
                                    <div class="ml-4 w-5/6">
                                        <strong><?php echo e($review->book->title); ?></strong><br/>
                                        <a class="text-gray-600 text-sm"><?php echo e($review->created_at->diffForHumans()); ?></a><br/>
                                        <?php for($i = 0; $i < $review->rating; $i++): ?>
                                            <a class="text-gray-600 text-sm">★</a>
                                        <?php endfor; ?>
                                        <p><?php echo e($review->content); ?></p>
                                        <?php if(Auth::check() && (Auth::user()->id == $user->id || Auth::user()->is_admin)): ?>
                                            <form action="/reviews/<?php echo e($review->id); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <?php if(Auth::check() && Auth::user()->id == $user->id): ?>
                                                    <a class="text-indigo-600 text-sm" href="<?php echo e(route('reviews.edit', $review->id)); ?>">Edit My Review</a> ・ 
                                                <?php endif; ?>
                                                <button type="submit" class="text-red-600 text-sm">Delete this review</button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\uas-kelompok-lachisean\uas-kelompok-lachisean\resources\views/users/show.blade.php ENDPATH**/ ?>