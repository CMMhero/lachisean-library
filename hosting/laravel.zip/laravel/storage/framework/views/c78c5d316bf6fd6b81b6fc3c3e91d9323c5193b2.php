<h1>Lachisean Library</h1>

<form action="/books/search" method="post">
  <?php echo csrf_field(); ?>
  <input type="text" name="query">
  <button type="submit">Search</button>
</form>

<ul>
  <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li><?php echo e($book->title); ?> - <?php echo e($book->author); ?> - <?php echo e($book->category->name); ?></li>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>

<?php /**PATH C:\xampp\htdocs\uas-kelompok-lachisean\uas-kelompok-lachisean\resources\views/index.blade.php ENDPATH**/ ?>